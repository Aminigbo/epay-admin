async function signupController(req, res) {
   res.send("Hello")
   console.log(req)
}

module.exports = {
   signupController
}